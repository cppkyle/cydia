var vertical_spacing = 200;
var notification_spacing = 55;
var xhour = true;